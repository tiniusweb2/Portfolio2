import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const type = searchParams.get('type')
  const url = searchParams.get('url')

  if (!type || !url) {
    return new NextResponse('Missing type or url parameter', { status: 400 })
  }

  let content = ''

  switch (type) {
    case 'image':
      content = `<img src="${url}" alt="Media content" class="max-w-full max-h-[70vh] object-contain" />`
      break
    case 'video':
      content = `<video src="${url}" controls class="max-w-full max-h-[70vh]"></video>`
      break
    case 'audio':
      content = `<audio src="${url}" controls class="w-full"></audio>`
      break
    default:
      content = '<p class="text-blue-100">Unsupported media type</p>'
  }

  return new NextResponse(content, {
    headers: { 'Content-Type': 'text/html' },
  })
}

