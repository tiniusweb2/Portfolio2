import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const email = formData.get('email');
  const phone = formData.get('phone');
  const message = formData.get('message');

  // Here you would typically send an email or save to a database
  console.log('Received contact form submission:', { email, phone, message });

  const responseHtml = `
    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
      <p class="font-bold">Thank you!</p>
      <p>Your message has been sent successfully. We'll get back to you soon.</p>
    </div>
  `;

  return new NextResponse(responseHtml, {
    headers: { 'Content-Type': 'text/html' },
  });
}

