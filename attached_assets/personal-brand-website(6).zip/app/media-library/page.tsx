'use client'

import { useState } from 'react'
import Background from '../../components/Background'
import { MediaTree } from '../../components/MediaTree'
import { MediaViewer } from '../../components/MediaViewer'
import ModalMediaPlayer from '../../components/ModalMediaPlayer'
import RightSidebar from '../../components/RightSidebar'

type MediaItem = {
  id: string
  name: string
  type: 'folder' | 'image' | 'video' | 'audio'
  children?: MediaItem[]
  url?: string
}

const sampleData: MediaItem[] = [
  {
    id: '1',
    name: 'Images',
    type: 'folder',
    children: [
      { id: '1-1', name: 'Profile Picture', type: 'image', url: '/placeholder.svg?height=300&width=300' },
      { id: '1-2', name: 'Project Screenshot', type: 'image', url: '/placeholder.svg?height=300&width=300' },
    ],
  },
  {
    id: '2',
    name: 'Videos',
    type: 'folder',
    children: [
      { id: '2-1', name: 'Project Demo', type: 'video', url: 'https://example.com/demo.mp4' },
    ],
  },
  {
    id: '3',
    name: 'Audio',
    type: 'folder',
    children: [
      { id: '3-1', name: 'Podcast Episode', type: 'audio', url: 'https://example.com/podcast.mp3' },
    ],
  },
]

export default function MediaLibrary() {
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleSelectMedia = (item: MediaItem) => {
    setSelectedMedia(item)
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden p-8">
      <Background />
      <div className="z-10 w-full max-w-6xl">
        <h1 className="text-4xl font-bold text-blue-100 mb-8">Media Library</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <MediaTree data={sampleData} onSelectMedia={handleSelectMedia} />
          <MediaViewer selectedMedia={selectedMedia} setIsModalOpen={setIsModalOpen} />
        </div>
      </div>
      {isModalOpen && (
        <ModalMediaPlayer onClose={() => setIsModalOpen(false)} />
      )}
      <RightSidebar />
    </main>
  )
}

