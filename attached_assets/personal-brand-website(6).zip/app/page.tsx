import Background from "../components/Background"
import FloatingCard from "../components/FloatingCard"
import GithubProjectCard from "../components/GithubProjectCard"
import Sidebar from "../components/Sidebar"

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden">
      <Background />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 z-10 w-full max-w-6xl mx-auto px-4">
        <FloatingCard id="about" title="About Me" content="I'm a passionate developer and designer." isAbout={true} />
        <FloatingCard id="work" title="My Work" content="Check out my latest projects and achievements.">
          <div className="mt-4 space-y-4 max-h-[400px] overflow-y-auto pr-2">
            <GithubProjectCard
              title="Project 1"
              description="A React-based personal portfolio website with dynamic content loading."
              githubUrl="https://github.com/yourusername/project1"
            />
            <GithubProjectCard
              title="Project 2"
              description="An e-commerce platform built with Next.js and Stripe integration."
              githubUrl="https://github.com/yourusername/project2"
            />
            <GithubProjectCard
              title="Project 3"
              description="A real-time chat application using Socket.io and Express."
              githubUrl="https://github.com/yourusername/project3"
            />
          </div>
        </FloatingCard>
        <FloatingCard
          id="contact"
          title="Contact"
          content="Get in touch with me for collaborations."
          isContact={true}
        />
      </div>
      <div id="contact-form" className="mt-8 w-full max-w-md"></div>
      <Sidebar />
    </main>
  )
}

