"use client"

import { motion } from "framer-motion"
import Tilt from "react-parallax-tilt"
import { useState } from "react"

interface FloatingCardProps {
  id: string
  title: string
  content: string
  isContact?: boolean
  isAbout?: boolean
  children?: React.ReactNode
}

export default function FloatingCard({ id, title, content, isContact, isAbout, children }: FloatingCardProps) {
  const [isOpen, setIsOpen] = useState(false)
  return (
    <Tilt className="parallax-effect" perspective={1000} scale={1.01} transitionSpeed={2500}>
      <motion.div
        id={id}
        className="bg-blue-900 bg-opacity-30 backdrop-filter backdrop-blur-lg rounded-xl p-6 shadow-xl border border-blue-300 border-opacity-30"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-2xl font-bold mb-4 text-blue-100">{title}</h2>
        <p className="text-blue-50">{content}</p>
        {isAbout && (
          <>
            <button
              className="mt-4 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
              hx-get="/api/about-me"
              hx-target="#about-content"
              hx-swap="innerHTML"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? "Read Less" : "Read More"}
            </button>
            <div id="about-content" className="mt-4"></div>
          </>
        )}
        {isContact && (
          <button
            className="mt-4 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
            hx-post="/api/contact-form"
            hx-target="#contact-form"
            hx-swap="innerHTML"
          >
            Contact Me
          </button>
        )}
        {children && (
          <button
            className="mt-4 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? "Hide Projects" : "Show Projects"}
          </button>
        )}
        {isOpen && children}
      </motion.div>
    </Tilt>
  )
}

