import { motion } from "framer-motion"

interface GithubProjectCardProps {
  title: string
  description: string
  githubUrl: string
}

export default function GithubProjectCard({ title, description, githubUrl }: GithubProjectCardProps) {
  return (
    <motion.div
      className="bg-blue-800 bg-opacity-50 rounded-lg p-4 h-full flex flex-col justify-between"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h3 className="text-xl font-semibold text-blue-100 mb-2">{title}</h3>
      <p className="text-blue-200 mb-4">{description}</p>
      <a
        href={githubUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4 text-center"
      >
        View on GitHub
      </a>
    </motion.div>
  )
}

