'use client'

import { useState } from 'react'
import { Folder, File, ChevronRight, ChevronDown } from 'lucide-react'

type MediaItem = {
  id: string
  name: string
  type: 'folder' | 'image' | 'video' | 'audio'
  children?: MediaItem[]
}

interface MediaTreeProps {
  data: MediaItem[]
  onSelectMedia: (item: MediaItem) => void
}

const MediaTreeItem: React.FC<{ item: MediaItem; onSelectMedia: (item: MediaItem) => void }> = ({ item, onSelectMedia }) => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleOpen = () => {
    if (item.type === 'folder') {
      setIsOpen(!isOpen)
    }
  }

  const handleSelect = () => {
    if (item.type !== 'folder') {
      onSelectMedia(item)
    }
  }

  return (
    <div>
      <div
        className={`flex items-center space-x-2 p-2 hover:bg-blue-700 hover:bg-opacity-50 rounded cursor-pointer ${
          item.type !== 'folder' ? 'pl-6' : ''
        }`}
        onClick={item.type === 'folder' ? toggleOpen : handleSelect}
      >
        {item.type === 'folder' && (
          <span className="text-blue-300">
            {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
          </span>
        )}
        <span className="text-blue-300">
          {item.type === 'folder' && <Folder size={16} />}
          {item.type === 'image' && <File size={16} />}
          {item.type === 'video' && <File size={16} />}
          {item.type === 'audio' && <File size={16} />}
        </span>
        <span className="text-blue-100">{item.name}</span>
      </div>
      {item.type === 'folder' && isOpen && item.children && (
        <div className="pl-4">
          {item.children.map((child) => (
            <MediaTreeItem key={child.id} item={child} onSelectMedia={onSelectMedia} />
          ))}
        </div>
      )}
    </div>
  )
}

export const MediaTree: React.FC<MediaTreeProps> = ({ data, onSelectMedia }) => {
  return (
    <div className="bg-blue-900 bg-opacity-50 rounded-lg p-4 max-h-[600px] overflow-y-auto">
      {data.map((item) => (
        <MediaTreeItem key={item.id} item={item} onSelectMedia={onSelectMedia} />
      ))}
    </div>
  )
}

