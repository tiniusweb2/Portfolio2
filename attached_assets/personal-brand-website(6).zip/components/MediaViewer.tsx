'use client'

import { useState } from 'react'
//import ModalMediaPlayer from './ModalMediaPlayer'

type MediaItem = {
  id: string
  name: string
  type: 'folder' | 'image' | 'video' | 'audio'
  url?: string
}

interface MediaViewerProps {
  selectedMedia: MediaItem | null
  setIsModalOpen: React.Dispatch<React.SetStateAction<boolean>>
}

export const MediaViewer: React.FC<MediaViewerProps> = ({ selectedMedia, setIsModalOpen }) => {
  //const [isModalOpen, setIsModalOpen] = useState(false)

  if (!selectedMedia) {
    return (
      <div className="bg-blue-900 bg-opacity-50 rounded-lg p-4 flex items-center justify-center h-[600px]">
        <p className="text-blue-100">Select a media item to view</p>
      </div>
    )
  }

  return (
    <div className="bg-blue-900 bg-opacity-50 rounded-lg p-4 flex flex-col items-center justify-center h-[600px]">
      <button
        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
        hx-get={`/api/media-modal?type=${selectedMedia.type}&url=${selectedMedia.url}`}
        hx-target="#modal-content"
        hx-trigger="click"
        onClick={() => setIsModalOpen(true)}
      >
        View {selectedMedia.name}
      </button>
      <p className="text-blue-100 mt-4">{selectedMedia.name}</p>
      {/*isModalOpen && (
        <ModalMediaPlayer onClose={() => setIsModalOpen(false)} />
      )*/}
    </div>
  )
}

