'use client'

import { useEffect, useRef } from 'react'
import { X } from 'lucide-react'

interface ModalMediaPlayerProps {
  onClose: () => void
}

export default function ModalMediaPlayer({ onClose }: ModalMediaPlayerProps) {
  const modalRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    document.addEventListener('mousedown', handleOutsideClick)
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick)
    }
  }, [onClose])

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div ref={modalRef} className="bg-blue-900 bg-opacity-90 rounded-lg p-4 max-w-3xl max-h-[90vh] overflow-auto">
        <div className="flex justify-end mb-2">
          <button onClick={onClose} className="text-blue-100 hover:text-blue-200">
            <X size={24} />
          </button>
        </div>
        <div id="modal-content" className="flex items-center justify-center">
          {/* Content will be injected here by HTMX */}
        </div>
      </div>
    </div>
  )
}

