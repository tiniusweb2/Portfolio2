'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { FolderOpen } from 'lucide-react'
import { usePathname } from 'next/navigation'

export default function Sidebar() {
  const pathname = usePathname()

  if (pathname !== '/') {
    return null
  }

  return (
    <motion.div
      className="fixed left-0 top-0 h-screen w-16 bg-blue-800 bg-opacity-30 backdrop-filter backdrop-blur-lg border-r border-blue-300 border-opacity-30 z-50 flex flex-col items-center justify-center"
      initial={{ x: -64 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Link href="/media-library" className="p-2 bg-blue-500 bg-opacity-50 rounded-full hover:bg-opacity-75 transition-all duration-300">
        <FolderOpen className="w-6 h-6 text-white" />
      </Link>
    </motion.div>
  )
}

